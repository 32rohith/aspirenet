# Authentication API Setup Guide

This guide will help you set up and run the Auth0 authentication backend API.

## Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Auth0 account

## Installation

### 1. Install Dependencies

```bash
cd backend/authentication-api
npm install
```

### 2. Configure Auth0

1. Go to [Auth0 Dashboard](https://manage.auth0.com/)
2. Create a new API:
   - Name: AspireNet API
   - Identifier: `https://aspirenet-api` (or your preferred identifier)
   - Signing Algorithm: RS256

3. Create a new Application (Native/Mobile):
   - Name: AspireNet Mobile App
   - Type: Native
   - Note down the Client ID and Domain

4. Enable Database Connection:
   - Go to Authentication > Database
   - Enable "Username-Password-Authentication"

5. Enable Social Connections (optional):
   - Go to Authentication > Social
   - Enable Google, Apple, and/or Facebook
   - Configure each with their respective credentials

### 3. Configure Environment Variables

Create a `.env` file in the `backend/authentication-api` directory:

```bash
cp env.example .env
```

Edit `.env` with your Auth0 credentials:

```env
PORT=3000
AUTH0_DOMAIN=https://YOUR_AUTH0_DOMAIN.auth0.com
AUTH0_AUDIENCE=YOUR_AUTH0_API_IDENTIFIER
```

**Example:**
```env
PORT=3000
AUTH0_DOMAIN=https://dev-abc123.us.auth0.com
AUTH0_AUDIENCE=https://aspirenet-api
```

### 4. Build TypeScript

```bash
npm run build
```

## Running the Server

### Development Mode (with auto-reload)

```bash
npm run dev
```

The server will start on `http://localhost:3000` with hot-reloading enabled.

### Production Mode

```bash
npm run build
npm start
```

## API Endpoints

### Public Endpoints

#### Health Check
```
GET /
```

Returns server status.

**Response:**
```json
{
  "message": "hello world"
}
```

### Protected Endpoints (Require JWT Token)

#### Verify Authentication
```
GET /protected
Authorization: Bearer <JWT_TOKEN>
```

Verifies that the user is authenticated.

**Response:**
```json
{
  "message": "You are logined successfully"
}
```

#### Get User ID
```
GET /user
Authorization: Bearer <JWT_TOKEN>
```

Returns authenticated user information from JWT.

**Response:**
```json
{
  "message": "UserId successfully recived.",
  "user": {
    "sub": "auth0|user_id",
    "email": "user@example.com"
  }
}
```

## Authentication Flow

1. **User Signs Up/Logs In** (Flutter App)
   - User authenticates through Auth0 (via Flutter app)
   - Auth0 returns an access token (JWT)

2. **Token Verification** (This Backend)
   - Flutter app sends requests with `Authorization: Bearer <token>` header
   - Middleware (`JWTcheck`) verifies token with Auth0
   - If valid, request proceeds; otherwise, returns 401 Unauthorized

3. **Access Protected Routes**
   - User can access protected endpoints with valid token

## Middleware

### JWTcheck Middleware

Located at `src/middleware/JWTcheck.ts`

This middleware:
- Validates JWT tokens using Auth0's RS256 algorithm
- Checks token signature against Auth0's public keys
- Verifies audience and issuer
- Attaches user info to `req.auth`

**Usage:**
```typescript
import { JWTcheck } from "./middleware/JWTcheck.js";

app.get("/protected-route", JWTcheck, (req, res) => {
  const userId = req.auth?.sub;
  const email = req.auth?.email;
  // Your protected route logic
});
```

## Project Structure

```
backend/authentication-api/
├── src/
│   ├── app.ts                      # Main application entry
│   ├── controller/
│   │   └── user.controller.ts      # User-related controllers
│   ├── middleware/
│   │   └── JWTcheck.ts            # JWT verification middleware
│   └── types/
│       └── express.d.ts           # TypeScript type definitions
├── dist/                          # Compiled JavaScript (generated)
├── package.json
├── tsconfig.json
├── nodemon.json
└── .env                           # Environment variables (create this)
```

## Testing

### Test Health Check
```bash
curl http://localhost:3000/
```

### Test Protected Route

1. Get a valid JWT token from Auth0 (via the Flutter app or Auth0 dashboard)
2. Test the protected endpoint:

```bash
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:3000/protected
```

**Expected Response:**
```json
{
  "message": "You are logined successfully"
}
```

### Test User Endpoint

```bash
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:3000/user
```

## Troubleshooting

### "AUTH0_DOMAIN is undefined"

- Ensure `.env` file exists in `backend/authentication-api/`
- Verify environment variables are set correctly
- Restart the server after modifying `.env`

### "Invalid token" or "401 Unauthorized"

- Check that the token is valid and not expired
- Verify `AUTH0_DOMAIN` and `AUTH0_AUDIENCE` match Auth0 configuration
- Ensure token is sent in the `Authorization` header as `Bearer <token>`

### "Module not found" errors

- Run `npm install` to ensure all dependencies are installed
- Run `npm run build` to compile TypeScript

### Port already in use

- Change `PORT` in `.env` file
- Or stop the process using port 3000:
  ```bash
  # Windows
  netstat -ano | findstr :3000
  taskkill /PID <PID> /F
  
  # macOS/Linux
  lsof -ti:3000 | xargs kill
  ```

## Security Best Practices

1. **Never commit `.env` file** - It's already in `.gitignore`
2. **Use HTTPS in production** - Configure reverse proxy (nginx, etc.)
3. **Rotate secrets regularly** - Update Auth0 secrets periodically
4. **Enable rate limiting** - Add rate limiting middleware for production
5. **Monitor logs** - Set up logging and monitoring

## Adding New Protected Routes

To add a new protected route:

```typescript
import { JWTcheck } from "./middleware/JWTcheck.js";

app.get("/your-protected-route", JWTcheck, (req, res) => {
  // Access user info from req.auth
  const user = req.auth;
  
  // Your route logic here
  res.json({
    message: "Success",
    userId: user?.sub,
  });
});
```

## Environment Variables Reference

| Variable | Description | Required | Example |
|----------|-------------|----------|---------|
| `PORT` | Server port | No (default: 3000) | `3000` |
| `AUTH0_DOMAIN` | Auth0 tenant domain | Yes | `https://dev-abc123.us.auth0.com` |
| `AUTH0_AUDIENCE` | Auth0 API identifier | Yes | `https://aspirenet-api` |

## Scripts

- `npm run dev` - Start development server with auto-reload
- `npm run build` - Compile TypeScript to JavaScript
- `npm start` - Start production server (requires build first)

## Support

For issues:
1. Check Auth0 logs in the dashboard
2. Check server console logs
3. Verify environment configuration
4. Review Auth0 documentation: https://auth0.com/docs

## Next Steps

1. Set up `.env` file with Auth0 credentials
2. Run `npm install` and `npm run dev`
3. Test endpoints with valid JWT tokens
4. Integrate with Flutter frontend
5. Deploy to production server

## Production Deployment

For production:
1. Use a proper Node.js process manager (PM2, Forever)
2. Set up reverse proxy (nginx)
3. Enable HTTPS
4. Configure CORS properly
5. Add logging and monitoring
6. Set up rate limiting
7. Enable compression
8. Use environment-specific configurations

